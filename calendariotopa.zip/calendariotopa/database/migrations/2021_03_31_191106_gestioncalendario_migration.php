<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class GestioncalendarioMigration extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('gestioncalendario', function (Blueprint $table) {
            $table->id();
            $table->integer('categoria_id')->unsigned();
            $table->integer('activids_id')->unsigned();
            $table->string('fecha_inicio');
            $table->string('fecha_final');
            $table->integer('gestion');
            $table->integer('periodo');
            $table->foreign('categoria_id')->references('id')->on('categoria')->onDelete('cascade');
            $table->foreign('activids_id')->references('id')->on('activids')->onDelete('cascade');

            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('gestioncalendario');
    }
}
