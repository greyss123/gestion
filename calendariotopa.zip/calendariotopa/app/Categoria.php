<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use App\Actividad;

class Categoria extends Model
{
    protected $table="categoria";
    protected $fillable = [
        'nombre','estado'
    ];
    public function actividades(){
        return $this->hasMany(Actividad::class);
   }
    public function gestiones(){
        return $this->hasMany(App\Gestioncalendario::class);
    }
  

}
