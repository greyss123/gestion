<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use App\Categoria;
use App\Actividad;

class Administrativas extends Model
{
    protected $table="administrativas";
    protected $fillable = [
       'categoria_id','activids_id','fecha_inicio','fecha_final','gestion','periodo'
    ];
}
