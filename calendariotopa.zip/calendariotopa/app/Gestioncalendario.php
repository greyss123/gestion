<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use App\Categoria;
use App\Actividad;

class Gestioncalendario extends Model
{
    protected $table="gestioncalendario";
    protected $fillable = [
       'categoria_id','activids_id','fecha_inicio','fecha_final','gestion','periodo'
    ];
    public function categoria(){
        return $this->belongsTo(Categoria::class);
    }

    public function actividad(){
        //dd('hola');
        return $this->belongsTo(Actividad::class,'activids_id');
    }

}
