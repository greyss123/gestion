<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use App\Categoria;
class Actividad extends Model
{
    protected $table="activids";
    protected $fillable = [
       'categoria_id', 'nombre','estado'
    ];
    public function categoria(){
    return $this->belongsTo(Categoria::class);
    }

    public function gestiones(){
        return $this->hasMany(App\Gestioncalendario::class);
    }
    

}
