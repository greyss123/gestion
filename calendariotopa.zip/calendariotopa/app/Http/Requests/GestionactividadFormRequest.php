<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class GestioncalendarioFormRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
                'categoria_id' => 'required|max:255',
                'activids_id' => 'required|max:255',
                'fecha_inicio' => 'required|max:255',
                'fecha_final' => 'required|max:255',
                'gestion' => 'required|max:255',
                'periodo' => 'required|max:255',
                
        ];
    }
}
