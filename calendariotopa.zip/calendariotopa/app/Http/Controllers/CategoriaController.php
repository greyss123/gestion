<?php

namespace App\Http\Controllers;

use App\Http\Requests\CategoriaFormRequest;
use Illuminate\Http\Request;
use App\Categoria;

class CategoriaController extends Controller
{
    //public function create()
    //{
       // return view('Categoria.createcate');
    //}
    public function prueba()
    {
        return view('layouts.login');
    }
    public function store(Request $request)
    {
        $categoria= new Categoria();
        $categoria->nombre = request('nombre');
        $categoria->estado = request('estado');
        $categoria->save();

        return redirect('/categoria');
    }
    
    public function index(){
        $categorias = Categoria::all();
        return view('Categoria.categoriaindex', compact('categorias'));
    }
    public function show($id)
    {
        return view('categoria.show',['cat'=>Categoria::findOrFail($id)]);
    }
     
    public function edit($id)
    {
        return view('categoria.edit',['cat'=>Categoria::findOrFail($id)]);
    }
    public function update(CategoriaFormRequest $request, $id)
    {
       
        $categoria= Categoria::findOrFail($id);

        $categoria->nombre = $request->get('nombre');
        $categoria->estado = $request->get('estado');
        $categoria->update();

        return redirect('/categoria');
    }

   
    public function destroy($id)
    {
        $categoria = Categoria::findOrFail($id);

        $categoria->delete();
        
        return redirect('/categoria');
    }
}


