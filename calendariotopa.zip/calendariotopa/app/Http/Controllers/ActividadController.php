<?php

namespace App\Http\Controllers;

use App\Http\Requests\ActividadFormRequest;
use Illuminate\Http\Request;
use App\Actividad;
use App\Categoria;

class ActividadController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        //dd('hola');
        if($request){
           $query = trim($request->get('search'));

            $data =Actividad::where('nombre', 'LIKE', '%' .$query. '%')
            ->orderBy('id','asc')
            ->get();
            //dd($query);
           return view('client.lista.actividad',['data'=> $data, 'search'=>$query]);
       }
        //$data=Actividad::all()->sortBy('id',);
        //dd($data);
        //return view('client.lista.actividad',compact('data'));
    }

    
    public function create()
    {
       $categorias = Categoria::All();
       // $actividades = Actividad::all();
        return view('client.lista.createacti', compact(['categorias']));
        
    }

    
    public function store(Request $request)
    {
        //($request->all());
        $actividad = new Actividad();

        $actividad->categoria_id = request('categoria_id');
        $actividad->nombre = request('nombre');
        $actividad->estado = request('estado');
        $actividad->save();

        return redirect('/actividades');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        return view('client.lista.show',['da'=>Actividad::findOrFail($id)]);
    }

    
    public function edit($id)
    {
        return view('client.lista.edit',['da'=>Actividad::findOrFail($id)]);
    }

    
    public function update(ActividadFormRequest $request, $id)
    {
        $actividad = Actividad::findOrFail($id);

        $actividad->categoria_id = $request->get('categoria_id');
        $actividad->nombre = $request->get('nombre');
        $actividad->estado = $request->get('estado');
        $actividad->update();

        return redirect('/actividades');
    }

   
    public function destroy($id)
    {
        Actividad::destroy($id);
        return redirect('/actividades');
    }
}
