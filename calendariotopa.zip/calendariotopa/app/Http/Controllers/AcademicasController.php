<?php

namespace App\Http\Controllers;
use App\Http\Requests\AcademicasFormRequest;
use Illuminate\Http\Request;
use App\Academicas;
use App\Categoria;
use App\Actividad;

class AcademicasController extends Controller
{
    
    public function index()
    {
        $iden="Actividades académicas";
        $categoria = Categoria::where('nombre',$iden)->get()->first();
        $categorias= Categoria::all();
        $id=$categoria->id;
        $actividades = Actividad::where('categoria_id',$id)->get();
       // dd($actividades);
        return view('academicas.index', compact(['categorias', 'actividades']));
    }

    public function create()
    {
        //
    }

   
    public function store(Request $request)
    {
        //
    }

   
    public function show($id)
    {
        //
    }

    
    public function edit($id)
    {
        //
    }

    
    public function update(Request $request, $id)
    {
        //
    }

    function destroy($id)
    {
        //
    }
}
