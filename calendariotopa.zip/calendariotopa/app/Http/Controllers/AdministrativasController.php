<?php

namespace App\Http\Controllers;
use App\Http\Requests\AdministrativasFormRequest;
use Illuminate\Http\Request;
use App\Administrativas;
use App\Categoria;
use App\Actividad;

class AdministrativasController extends Controller
{
    
    public function index()
    {
        $iden="Actividades administrativas";
        $categoria = Categoria::where('nombre',$iden)->get()->first();
        $categorias= Categoria::all();
        $id=$categoria->id;
        $actividades = Actividad::where('categoria_id',$id)->get();
       // dd($actividades);
        return view('administrativas.index', compact(['categorias', 'actividades']));
    }

    public function create()
    {
        //
    }

   
    public function store(Request $request)
    {
        //
    }

   
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
