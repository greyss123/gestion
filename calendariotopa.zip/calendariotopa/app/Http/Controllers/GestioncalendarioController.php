<?php

namespace App\Http\Controllers;


use App\Http\Requests\GestioncalendarioFormRequest;
use Illuminate\Http\Request;
use App\Gestioncalendario;
use App\Categoria;
use App\Actividad;

class GestioncalendarioController extends Controller
{
    //public function todas()
    //{

        //$actividades = Actividad::all();
       // $actividades = Actividad::first();
       // dd($actividades->categoria());
       // return view('gestioncalendario.createfechas', compact('gestioncalendario'));
   // }
    public function index()
    {
        $gescal=Gestioncalendario::all()->sortBy('id');

        //dd($aaa);
        return view('gestioncalendario.index',compact('gescal'));
    }

   
    public function create()
    {
        $iden="Admisiones";
        $categoria = Categoria::where('nombre',$iden)->get()->first();
        $categorias= Categoria::all();
        $id=$categoria->id;
        $actividades = Actividad::where('categoria_id',$id)->get();
       // dd($actividades);
        return view('gestioncalendario.create', compact(['categorias', 'actividades']));
    }

   
    public function store(Request $request)
    {
        $gestioncalendario = new Gestioncalendario();

        $gestioncalendario->categoria_id = request('categoria_id');
        $gestioncalendario->activids_id = request('activids_id');
        $gestioncalendario->fecha_inicio = request('fecha_inicio');
        $gestioncalendario->fecha_final = request('fecha_final');
        $gestioncalendario->gestion = request('gestion');
        $gestioncalendario->periodo = request('periodo');
        $gestioncalendario->save();

        return redirect()->route('gestioncalendario.index');
    }

   
    public function show($id)
    {
        return view('gestioncalendario.show',['gescalen'=>Gestioncalendario::findOrFail($id)]);
    }

    public function edit($id)
    {
        return view('gestioncalendario.edit',['gescalen'=>Gestioncalendario::findOrFail($id)]);
    }

  
    public function update(GestioncalendarioFormRequest $request, $id)
    {
        $gestioncalendario = Gestioncalendario::findOrFail($id);

        $gestioncalendario->categoria_id = $request->get('categoria_id');
        $gestioncalendario->activids_id = $request->get('activids_id');
        $gestioncalendario->fecha_inicio = $request->get('fecha_inicio');
        $gestioncalendario->fecha_final = $request->get('fecha_final');
        $gestioncalendario->gestion = $request->get('gestion');
        $gestioncalendario->periodo = $request->get('periodo');
        $gestioncalendario->update();

        return redirect('/gestioncalendario');
    }

   
    public function destroy($id)
    {
        $gestioncalendario = Gestioncalendario::findOrFail($id);

        $gestioncalendario->delete();
        
        return redirect('/gestioncalendario');
    }
}
