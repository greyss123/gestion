<?php

namespace App\Http\Controllers;
use App\Http\Requests\AdmisionesFormRequest;
use Illuminate\Http\Request;
use App\Admisiones;
use App\Categoria;
use App\Actividad;

class AdmisionesController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $iden="Admisiones";
        $categoria = Categoria::where('nombre',$iden)->get()->first();
        $categorias= Categoria::all();
        $id=$categoria->id;
        $actividades = Actividad::where('categoria_id',$id)->get();
       // dd($actividades);
        return view('admisiones.index', compact(['categorias', 'actividades']));
    }
    public function create()
    {
        
    }

  
    

    
    public function show($id)
    {
        //
    }

   
    public function edit($id)
    {
        //
    }

    
    public function update(Request $request, $id)
    {
        //
    }

    
    public function destroy($id)
    {
        //
    }
}
